// Student: 
//     Student(String newName, String address, String phone, int year) 
//     toString()→ string 
//     getGraduationYear()→ int
//     setGraduationYear(int year)

public class Student extends Person{
    private int year;
    public Student(String newName, String address, String phone, int year) {
    super(newName, address, phone);
    this.year=year;
    }

    public void setGraduationYear(int year){
        this.year = year;
    }
    
    public int getGraduationYear(){
        return(this.year);
    }

    public String toString(){
        return super.toString()+","+year;}   
    }