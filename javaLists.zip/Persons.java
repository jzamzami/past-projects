// Persons: 
//     Persons() 
//     search(String name)→Persons 
//     add(Person/Student/Employee p)
//     getSize() → int 
//     delete(int i) 
//     getInternalList() → List

import java.util.ArrayList;

public class Persons {
    ArrayList<Person> personsList;

    Persons(){ 
        personsList = new ArrayList<Person>();
    }

    public Persons search(String name){
        Persons searchPerson = new Persons();   
        for (Person newPerson : personsList) {
            if (newPerson.getName() == name) {
                searchPerson.add(newPerson);
            }
        }return searchPerson;
    }
    
    public void add(Person p){
        personsList.add(p);
    }

    public int getSize(){
        return personsList.size();
    }

    public void delete(int i){
        personsList.remove(i);
    }

    public ArrayList<Person> getInternalList(){
        return personsList;
    }
}