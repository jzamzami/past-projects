import java.util.Scanner;

class MyMainProgram{
    public static String readingInput(Scanner k){
        String result = k.nextLine().toLowerCase();
        return result;
    }

    public static int readingIntInput(Scanner k){
        int result = k.nextInt();
        return result;
    }
    
    public static void enterNewPerson(Persons P, Scanner k){
        System.out.println("What is the name of your person?");
        String newName = k.nextLine();
        System.out.println("What is the address of your person?");
        String newAddress = k.nextLine();
        System.out.println("What is the number of your person?");
        String newPhonenum = k.nextLine();
        System.out.println("Is your person a student?");
        String input = k.nextLine();
        if(input == "y"){
            System.out.println("What is the graduation year?");
            int year = k.nextInt();
            Student newStudent = new Student(newName, newAddress, newPhonenum, year);
            P.add(newStudent);
        }
        else{
            System.out.println("Is your person an employee?");
            String answer = k.nextLine();
            if(answer.equals("y")){
                System.out.println("What is the department?");
                String department = k.nextLine();
                Employee newEmployee = new Employee(newName, newAddress, newPhonenum, department);
                P.add(newEmployee);
            } else{
                Person newPerson = new Person(newName, newAddress, newPhonenum);
                P.add(newPerson);
            }
        }
    }

    public static void main(String[] args, Persons Persons, Persons P, String anObject, Object toDelete, Persons modifyResult) {
        Persons personInformation = new Persons();
        while(true){
                System.out.println("Enter option from list below:\n" + 
                "\t 1) Display complete directory\n" + 
                "\t 2) Enter new Person\n" + 
                "\t 3) Search for Person\n" + 
                "\t 4) Modify Person information\n" + 
                "\t 5) Delete a record.\n" + 
                "\t Q) Quit\n");
                Scanner k = new Scanner(System.in);
                String choice = readingInput(k);
                System.out.println("Enter your option: ");

                if(choice == "1"){
                    System.out.println(personInformation.getInternalList());
                    break;
                }
                
                else if(choice == "2"){
                    enterNewPerson(personInformation, k);
                    break;
                }
                
                else if(choice == "3"){
                    System.out.print("Enter the name to search: ");
                    Scanner l = new Scanner(System.in);
                    String searchName = readingInput(l);
                    Persons returnSearch = personInformation.search(searchName);
                    System.out.println(returnSearch);
                    break;
                }

                else if(choice == "4"){
                    System.out.print("Enter the name to search: ");
                    Scanner j = new Scanner(System.in);
                    String modifyName = readingInput(j);
                    personInformation.search(modifyName);
                    if (modifyResult.getSize()==0){
                        System.out.println("No match.");
                        break;
                    }
                }
                
                else if(choice == "5"){
                    System.out.print("Enter the index to delete: ");
                    Scanner i = new Scanner(System.in);
                    int deleteIndex = readingIntInput(i);
                    System.out.println("Is this the index you want to delete?");
                    i.nextLine();
                    if(toDelete.equals("y")){
                        personInformation.delete(deleteIndex);
                    }
                }

                else if(choice == "q"){
                    System.exit(0);
			        break;
                }
            }
        }
    }