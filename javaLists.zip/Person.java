// Person: 
//     Person(String newName, String address, String phone) 
//     setName(String name) 
//     getName()→ string 
//     getPhone()→ string 
//     toString()→ string 

class Person {
    private String name;
    private String address;
    private String phone;
    public Person(String newName, String address, String phone){
        this.name = newName;
        this.address = address;
        this.phone = phone;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return(this.name);
    }
    public String getPhone(){
        return(this.phone);
    }
    public String toString(){
        return(name + "," + address + "," + phone + ",");
    }
}