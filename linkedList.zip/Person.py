# __init__(newName="none", address="none", phone="999-999-9999") 
#     ◦ initializes a Person object

#     setName(string) 
#     ◦ sets the name of the object to be equal to the string parameter provided

#     getName()→ string 
#     ◦ returns the name of the Person as a string

#     getPhone()→ string 
#     ◦ returns the phone number of the Person as a string

class Person:
    def __init__(self, newName="none", address="none", phone="999-999-9999"):
        self.name = newName
        self.address = address
        self.phone = phone

    def setName(self, name):
        self.name = name

    def getName(self):
        return(self.name)

    def getPhone(self):
        return(self.phone)

    def __str__(self):
        stringtoReturn = "Name:" + self.name \
                       + "\nAddress: " + self.address \
                       + "\nPhone: " + self.phone 
        return(stringtoReturn)

if __name__=="__main__":
    samplePerson = Person("Jaime", "Crashboat Beach", "111-222-3333")
    print(samplePerson)