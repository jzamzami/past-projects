# __init__(newName="none", address="none", phone="999-999-9999", department=”not assigned”)
#     ◦ initializes an Employee object 5 points

#     getDepartment()→ string 
#     ◦ returns the Employee department, as a string

#     setDepartment(string) 
#     ◦ sets the department of the Employee object to be equal to the string parameter provided

from Person import Person

class Employee(Person):
    def __init__(self, newName="none", address="none", phone="999-999-9999", department="not assigned"):
        Person.__init__(self, newName, address, phone)
        self.department = department

    def setDepartment(self, department:str):
        self.department = department 

    def getDepartment(self):
        return(self.department)

    def __str__(self):
        stringtoReturn = "Name: " + self.name \
                       + "\nAddress: " + self.address \
                       + "\nPhone: " + self.phone \
                       + "\nDepartment: " + self.department
        return(stringtoReturn)

if __name__=="__main__":
    sampleEmployee = Employee("Jaime", "Crashboat Beach", "111-222-3333", "Computer Science")
    print(sampleEmployee)