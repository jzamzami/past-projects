# __init__(newName="none", address="none", phone="999-999-9999", year=9999) 
#     ◦ initializes a Student object

#     getGraduationYear()→ int 
#     ◦ returns the graduation year of the Student, as an integer

#     setGraduationYear(int) 
#     ◦ sets the graduation year of the Student to be equal to the integer parameter provided

from Person import Person

class Student(Person):
    def __init__(self, newName="none", address="none", phone="999-999-9999", year=9999):
        Person.__init__(self, newName, address, phone)
        self.year = year

    def setGraduationYear(self,year:int): 
        self.year = year

    def getGraduationYear(self):
        return(self.year) 

    def __str__(self):
        stringtoReturn = "Name: " + self.name \
                       + "\nAddress: " + self.address \
                       + "\nPhone: " + self.phone \
                       + "\nYear: " + str(self.year)
        return(stringtoReturn)

if __name__=="__main__":
    sampleStudent = Student("Jaime", "Crashboat Beach", "111-222-3333", 2023)
    print(sampleStudent)    