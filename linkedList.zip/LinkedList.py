# __init__() 
#     ◦ initializes an empty linked list

#     search(string)→LinkedList
#     ◦ returns a linked list of objects with a name attribute equal to the provided string

#     add(object) 
#     ◦ appends the object provided as parameter to the list

#     insert(int, object)
#     ◦ places the provided object at index equal to the provided integer

#     length() → int 
#     ◦ returns the length of the list as an integer

#     __getitem__(int) → Person 
#     ◦ returns the object stored at the index of the list equal to the integer provided as parameter

#     delete(int) 
#     ◦ deletes from the list the element at the index provided as parameter

from Node import Node
from Person import Person
from Student import Student
from Employee import Employee

class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def length(self):
        return(self.size)

    def add(self, e):
        n = Node()
        n.setData(e)
        if self.size == 0:
            self.head= n
            self.tail= n
        else:
            currentlyTheLastElement = self.tail
            n.setPrevious(currentlyTheLastElement)
            currentlyTheLastElement.setNext(n)
            self.tail = n
        self.size += 1
                
    def __getitem__(self, i):
        currentElement= self.head
        howManyIHaveSkippedOver = 0
        while (howManyIHaveSkippedOver < i):
            currentElement = currentElement.next
            howManyIHaveSkippedOver += 1
        return(currentElement.getData())

    def __iter__(self):
        current = self.head
        while current:
            yield current
            current = current.next

    def __str__(self):
        stringToReturn = ""
        for e in self:
            stringToReturn = stringToReturn + str(e) + "\n"
        return(stringToReturn)

    def delete(self, i):
        currentElement = self.head
        howManyIHaveSkippedOver = 0
        if i >= 0 and i <= self.size-1:
            while (howManyIHaveSkippedOver < i):
                currentElement = currentElement.next
                howManyIHaveSkippedOver += 1
            before = currentElement.getPrevious() 
            after = currentElement.getNext()
            if before is None:
                self.head = after
            else:
                before.setNext(after)
            if after is None:
                self.tail = before
            else:
                after.setPrevious(before)

    def insert(self, i, value):
        new = Node()
        new.setData(value)
        currentElement = self.head
        howManyIHaveSkippedOver = 0
        while (howManyIHaveSkippedOver < i-1):
            currentElement = currentElement.next
            howManyIHaveSkippedOver += 1
        before = currentElement.getPrevious()   
        after = currentElement.getNext()
        if after is None:
            self.tail = new
            new.next = None
            new.previous = currentElement
            currentElement.next = new
        else:
            new.next = currentElement
            if before is None:
                self.head = new
            else:
                before.next = new 
            currentElement.previous = new
            new.next = currentElement
            new.previous = before
            
    def search(self, elementLookingFor):
        current = self.head
        listOfMatches = LinkedList()
        while current:
            data = current.getData()
            name = data.getName()
            if name == elementLookingFor:
                listOfMatches.add(data)
            current = current.next
        return listOfMatches

if __name__=="__main__":
    samplePerson1 = Person("Jaime", "Crashboat Beach", "111-222-3333")
    samplePerson2 = Person("maria", "cape cod", "111-222-3333")
    samplePerson3 = Employee("Jaime", "Crashboat Beach", "111-222-3333", "Computer Science")
    samplePerson4 = Student("Jaime", "Crashboat Beach", "111-222-3333", 2023)
    myLinkedList = LinkedList()
    myLinkedList.add(samplePerson1)
    myLinkedList.add(samplePerson3)
    myLinkedList.add(samplePerson4)
    print(myLinkedList)
    print(myLinkedList.insert(2,samplePerson2))
    print(myLinkedList.insert(1,"Rob"))
    print(myLinkedList.insert(0,"David"))
    print(myLinkedList)
    print(myLinkedList.delete(0))
    print(myLinkedList.delete(3))
    print(myLinkedList.delete(5))
    print(myLinkedList)

    listOfIntegers = LinkedList()
    listOfIntegers.add(1)
    listOfIntegers.add(7)
    listOfIntegers.add(-2)
    print(listOfIntegers)
    print(listOfIntegers.insert(2,66))
    print(listOfIntegers.insert(1,55))
    print(listOfIntegers.insert(0,55))
    print(listOfIntegers)
    print(listOfIntegers.delete(0))
    print(listOfIntegers.delete(3))
    print(listOfIntegers.delete(5))
    print(listOfIntegers)