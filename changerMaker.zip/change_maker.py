print("Welcome to the vending machine change maker program\nChange maker initialized.")

nickel = 25
dime = 25
quarter = 25
one = 0
five = 0

stock = {
'nickels':nickel,
'dimes':dime,
'quarters':quarter, 
'ones':one,
'fives':five,
} 

nums = ['1','2','3','4','5','6','7','8','9','0','.']

print("Stock contains:")
print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
#print()

price = input("\nEnter the purchase price (xx.xx) or `q\' to quit: ")
total = 0
found = False

while (price != 'q'):
    for letter in price:
        if letter in nums:
            found = True
            break
        else:
            found = False
            break
    if found:
        price = float(price)
        price = int(price*100) 
        remaining = price
        total = 0
        while (remaining % 5 == 0 and remaining > 0):
            print()
            print("Menu for deposits:")
            print("  'n' - deposit a nickel")
            print("  'd' - deposit a dime")
            print("  'q' - deposit a quarter")
            print("  'o' - deposit a one dollar bill")
            print("  'f' - deposit a five dollar bill")
            print("  'c' - cancel the purchase")
            print()
            dollars = int(remaining//100)
            cents = int(remaining%100)
            if (dollars > 0 and remaining > 0):
                print('Payment due:', dollars, 'dollars and', cents, 'cents')
            elif (dollars <= 0 and cents > 0 and remaining > 0):
                print('Payment due:', cents, 'cents')
            deposit =  0
            while (deposit != 'c' or remaining > total):
                deposit = input('Indicate your deposit: ') 
                if deposit == 'n':
                    remaining -= 5
                    total += 5
                    dollars = int(remaining//100)
                    cents = int(remaining%100)
                    stock['nickels'] += 1
                    if (dollars > 0 and remaining > 0):
                        print('Payment due:', dollars, 'dollars and', cents, 'cents')
                    elif (dollars <= 0 and cents > 0 and remaining > 0):
                        print('Payment due:', cents, 'cents')
                    elif (dollars <= 0 and cents <= 0):
                        print()
                        print('Please take the change below.')
                        print ('   No change due.')
                        print()
                        print("Stock contains: ") 
                        print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
                        print()
                elif deposit == 'd':
                    remaining -= 10
                    total += 10
                    dollars = int(remaining//100)
                    cents = int(remaining%100)
                    stock['dimes'] += 1
                    if (dollars > 0 and remaining > 0):
                        print('Payment due:', dollars, 'dollars and', cents, 'cents')
                    elif (dollars <= 0 and cents > 0 and remaining > 0):
                        print('Payment due:', cents, 'cents')
                    elif (dollars <= 0 and cents <= 0):
                        print()
                        print('Please take the change below.')
                        print ('   No change due.')
                        print()
                        print("Stock contains: ") 
                        print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
                        print()
                elif deposit == 'q':
                    remaining -= 25
                    total += 25
                    dollars = int(remaining//100)
                    cents = int(remaining%100)
                    stock['quarters'] += 1
                    if (dollars > 0 and remaining > 0):
                        print('Payment due:', dollars, 'dollars and', cents, 'cents')
                    elif (dollars <= 0 and cents > 0 and remaining > 0):
                        print('Payment due:', cents, 'cents')
                    elif (dollars <= 0 and cents <= 0):
                        print()
                        print('Please take the change below.')
                        print ('   No change due.')
                        print()
                        print("Stock contains: ") 
                        print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
                        print()
                elif deposit == 'o':
                    remaining -= 100
                    total += 100
                    dollars = int(remaining//100)
                    cents = int(remaining%100)
                    stock['ones'] += 1
                    if (dollars > 0 and remaining > 0):
                        print('Payment due:', dollars, 'dollars and', cents, 'cents')
                    elif (dollars <= 0 and cents > 0 and remaining > 0):
                        print('Payment due:', cents, 'cents')
                    elif (dollars <= 0 and cents <= 0):
                        print()
                        print('Please take the change below.')
                        print ('   No change due.')
                        print()
                        print("Stock contains: ") 
                        print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
                        print()
                elif deposit == 'f':
                    remaining -= 500
                    total += 500
                    dollars = int(remaining//100)
                    cents = int(remaining%100) 
                    stock['fives'] += 1
                    if (dollars > 0 and remaining > 0):
                        print('Payment due:', dollars, 'dollars and', cents, 'cents')
                    elif (dollars <= 0 and cents > 0 and remaining > 0):
                        print('Payment due:', cents, 'cents')
                    elif (dollars <= 0 and cents <= 0):
                        print()
                        print('Please take the change below.')
                        print ('   No change due.')
                        print()
                        print("Stock contains: ") 
                        print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
                        print()
                elif (deposit != 'c'):
                    print('Illegal selection:', deposit)
                    if (dollars > 0 and remaining > 0):
                        print('Payment due:', dollars, 'dollars and', cents, 'cents')
                    elif (dollars <= 0 and cents > 0 and remaining > 0):
                        print('Payment due:', cents, 'cents')
                    elif (dollars <= 0 and cents <= 0):
                        print() 
                        print('Please take the change below.')
                        print ('   No change due.')
                        print()
                        print("Stock contains: ") 
                        print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
                        print()
                if (deposit == 'c' or remaining <= 0):
                    give_back = 0 
                    if (remaining < 0):
                        give_back = remaining * -1  
                    elif (remaining == 0): 
                        break 
                    elif (remaining > 0 or deposit == 'c'):
                        give_back = total
                    print()
                    print('Please take the change below.') 
                    if (stock['quarters'] > 0 and give_back >= 25):
                        quarter_total = give_back // 25
                        quarter_total = min([quarter_total, stock['quarters']])
                        stock['quarters'] -= quarter_total
                        give_back -= quarter_total*25      
                        print(f'  {quarter_total} quarters')
                    if (stock['dimes'] > 0 and give_back >= 10):
                        dime_total = give_back // 10
                        dime_total = min([dime_total, stock['dimes']])
                        stock['dimes'] -= dime_total
                        give_back -= dime_total*10 
                        print(f'  {dime_total} dimes')
                    if (stock['nickels'] > 0 and give_back >= 5):
                        nickel_total = give_back // 5
                        nickel_total = min([nickel_total, stock['nickels']])
                        stock['nickels'] -=  nickel_total
                        give_back -= nickel_total*5 
                        print(f'  {nickel_total} nickels')
                    if (give_back > 0): 
                        print("Machine is out of change.\nSee store manager for remaining refund.")
                        if (dollars > 0):
                            print('Amount due is: 17 dollars and 0 cents')
                        elif (dollars <= 0):
                            print('Amount due is: 5 cents')
                    remaining = 0
                    print()
                    print("Stock contains: ") 
                    print('\n'.join(f'   {value} {key}' for key, value in stock.items()))
                    print()
                    break
        else:
            if (price % 5 != 0 or price <= 0):
                print('Illegal price: Must be a non-negative multiple of 5 cents.')
                print()
    else:
        print('Invalid purchase price. Try again\n')
    price = input('Enter the purchase price (xx.xx) or `q\' to quit: ')
    #print()

n_total = stock['nickels'] * 5 
d_total = stock['dimes'] * 10
q_total = stock['quarters'] * 25 
o_total = stock['ones'] * 100 
f_total = stock['fives'] * 500 
stock_total = (n_total + d_total + q_total + o_total + f_total)
stock_dollar = stock_total // 100 
stock_cent = stock_total % 100
print()
print(f'Total: {stock_dollar} dollars and {stock_cent} cents')