import csv 
import sys 

#def read_dna(file_reader):
    #f = open('dna_1.txt', 'r')
    #file_reader = f.read()
    #return file_reader

def read_dna(dna_filename):
    f = open(dna_filename)
    dna = f.read()
    f.close()
    return dna

#def dna_length(dna_reader):
    #f = open('dna_1.txt', 'r')
    #dna_reader = f.read()
    #dna_reader = len(dna_reader)
    #return dna_reader 

def dna_length(dna_filename):
    counter = open(dna_filename)
    dna_filename = counter.read()
    counter = 0
    for i in dna_filename:
        counter += 1 
    return counter

#def read_strs(str_reader):
    #reader = open(str_reader)
    #list = []
    #for k in str_reader:
        #reader = list.append((k,(str_reader[k])))
    #return reader

def read_strs(str_filename):      
    reader = open(str_filename)
    reader = [*csv.DictReader(reader)]
    return reader

#def get_strs(str_profiler):
    #str = open(str_profiler)
    #new_str = []
    #for k, v in str_profiler.str():
        #new_str[str(k)] = str(v)
    #str.close()
    #return new_str 

def get_strs(str_profile):
    new_str = []
    for j in str_profile:
        if j != 'name':
            new_str.append((j,int(str_profile[j])))
    return new_str

def longest_str_repeat_count(str_frag, dna_seq):
    i = 0
    count = 0
    max_count = 0
    while i < len(dna_seq):
        if i + 4 <= len(dna_seq) and dna_seq[i:i+4] in str_frag:
            i += 4 
            count += 1
            if max_count < count:
                max_count = count 
        else:
            i += 1 
            count = 0
    return max_count 

def find_match(str_profile, dna_seq):
    str_1 = longest_str_repeat_count('AGAT', dna_seq)
    str_2 = longest_str_repeat_count('AATG', dna_seq)
    str_3 = longest_str_repeat_count('TATC', dna_seq)
    if str_1 == str_profile[0][1] and str_2 == str_profile[1][1] and str_3 == str_profile[2][1]:
        return True
    else: 
        return False

def dna_match(str_filename, dna_filename):
    str_profile = read_strs(str_filename)
    person_dna = read_dna(dna_filename)
    for person_str in str_profile: 
        person_strs = get_strs(person_str)
        person_match = find_match(person_strs, person_dna)
        if person_match:
            return person_str['name']
    return 'No match'

    #read the strs then read the dna
    #then use get_strs to find match (find which persons strs it matches) 
    #print the persons name using indices so if it matches profile[0] then it's Alice, etc.. 
    #if it doesnt match a single person then it should print no match
    #use functions (read_strs/read_dna/get_strs/find_match)


if __name__ == '__main__':
   print(read_dna('dna_1.txt'))
   print(dna_length('dna_1.txt'))
   print(read_strs('str_profiles.csv'))
   
if __name__ == '__main__':
   profiles = read_strs('str_profiles.csv')
   print(profiles)
   print(get_strs(profiles[0]))
   print(get_strs(profiles[0])[0] == ('AGAT', 5))
   #print(find_match((profiles[0]), read_dna('dna_1.txt')))
   #print(dna_match('str_profiles.csv','dna_1.txt'))
   